package main;
import java.util.Calendar;
import java.util.Scanner;
public class FolhaDePagamento {
    
   
    
    private String periododepagamento = new String();
    
    
    public void setPeriododepagamento(String periododepagamento)
    {
        this.periododepagamento = periododepagamento;
    }
    
    public String getPeriododepagamento()
    {
        return this.periododepagamento;
    }
    
    public int VerificarDiaSemana()
    {
        Calendar current = Calendar.getInstance();
        int semana = current.get(Calendar.DAY_OF_WEEK);
        return semana;
    }
    
    public int VerificarDiaMes()
    {
        Calendar current = Calendar.getInstance();
        int semana = current.get(Calendar.DATE);
        return semana;
    }
    
     //método para gerar pagamento de funcionários horista
    public void GerarPagamentoHorista(Empregados empregado, int dia)
    {
        int salary = empregado.getSalary(), taxa;
        salary = (salary/8)*(empregado.ponto.getHoratotal()-8);
        salary = salary + empregado.getSalary();
        if(empregado.getSindicato().equals("sim"))
        {
            taxa= empregado.getTaxasindical() + empregado.getTaxasadicionais();
            System.out.println("taxas= "+taxa+"salário= "+salary);
            salary= salary-taxa;
        }
        empregado.setSalaryfinal(salary);
        MostrarFolhaDePagamento(empregado, dia);
    }
    //fim do método para gerar pagamento de funcionários horista
    
     //método para gerar pagamento de funcionários comissionados
    public void GerarPagamentoComissionado(Empregados empregado,int dia)
    {
        int soma=0, i, venda=0;
        int salary = empregado.getSalary();
        for(i=0;i<empregado.vendas.size();i++)
        {
              soma= soma + empregado.vendas.get(i);
              //colocar essa venda para 0 pra não ser calculada novamente --> feito
        }
        salary= (salary+salary);
        salary= (salary+(soma*empregado.getPercentualvendas()));
        if(empregado.getSindicato().equals("sim"))
        {
            salary= salary-empregado.getTaxasindical();
            salary= salary-empregado.getTaxasadicionais();
        }
        empregado.setSalaryfinal(salary);
        MostrarFolhaDePagamento(empregado, dia);
    }
     //fim do método para gerar pagamento de funcionários comissionados
    
    //método para gerar pagamento de funcionários assalariados
    public void GerarPagamentoAssalariado(Empregados empregado, int dia)
    {
        int salary = empregado.getSalary();
        if(empregado.getSindicato().equals("sim"))
        {
            salary= salary-empregado.getTaxasindical();
            salary= salary-empregado.getTaxasadicionais();
        }
        empregado.setSalaryfinal(salary);
        MostrarFolhaDePagamento(empregado, dia);
    }
    //fim do método para gerar pagamento de funcionários assalariados
    
    
    
    //função gerar e mostrar folha de pagamento
    public void MostrarFolhaDePagamento(Empregados empregado, int dia)
    {
        Calendar current = Calendar.getInstance();
        int mes = current.get(Calendar.MONTH);
        int ano = current.get(Calendar.YEAR);
        System.out.print("\n");
        System.out.println("            FOLHA DE PAGAMENTO                 ");
        System.out.println("         GERADA NA DATA "+dia+"/"+mes+"/"+ano);
        System.out.println("Nome do funcionário: "+empregado.getNome()+".");
        System.out.println("Número de identificação do funcionário: "+empregado.getId()+".");
        System.out.println("Tipo do funcionário: "+empregado.getType()+".");
        System.out.println("Endereço: "+empregado.getAdress()+".");
        System.out.println("Salário: R$"+empregado.getSalaryfinal()+".");
        System.out.println("Forma de pagamento: "+empregado.getFormadepagamento()+".");
        System.out.println("Dia de pagamento: "+empregado.getDiadepagamento()+".");
        if(empregado.getSindicato().equals("sim"))
        {
            System.out.println("Taxa do sindicato: "+empregado.getTaxasindical());
            System.out.println("Taxas adicionasi: "+empregado.getTaxasadicionais());
            System.out.println("número do funcionário no sindicato: "+empregado.getIdsindicato());
        }
        if(empregado.getType().equals("horista"))
        {
            System.out.println("Hora de chegada: "+empregado.ponto.getHorachegada()+":00h.");
            System.out.println("Hora de saída: "+empregado.ponto.getHorasaida()+":00h.");
            System.out.println("Quantidade total de horas trabalhadas: "+empregado.ponto.getHoratotal()+":00h.");            
        }
        if(empregado.getType().equals("comissionado"))
        {
            int i;
            System.out.println("            VENDAS REALIZADAS                 ");
            for(i=0;i<empregado.datasVendas.size();i++)
            {
                System.out.println("Dia da venda "+empregado.datasVendas.get(i)+": "+empregado.vendas.get(i)+" vendas realizadas.");
                empregado.vendas.remove(empregado.vendas.get(i));
                empregado.datasVendas.remove(empregado.datasVendas.get(i));
            }
        } 
    }
    //fim da função gerar e mostrar folha de pagamento
    
    //função agenda de pagamento
    public void AgendaPagamento(Empregados empregado)
    {
        Scanner scanner = new Scanner(System.in);
        if(empregado.getType().equals("horista"))
        {
            System.out.println("O Funcionário "+empregado.getNome()+" é pago semanalmente no dia "+empregado.getDiadepagamento()+".");
        }
        if(empregado.getType().equals("comissionado"))
        {
              System.out.println("O Funcionário "+empregado.getNome()+" é pago bi-semanalmente no dia "+empregado.getDiadepagamento()+".");
        }
        if(empregado.getType().equals("assalariado"))
        {
             System.out.println("O Funcionário "+empregado.getNome()+" é pago mensalmente no dia "+empregado.getDiadepagamento()+".");  
        }
        System.out.println("Deseja alterar  a data de pagamento do funcionário?(digite sim ou nao)");
        String opcao = scanner.nextLine();
        if(opcao.equals("sim"))
        {
            AlterarAgendaPagamento(empregado);
        }
        else
        {
            return;
        }
    }
    //fim da função agenda de pagamento
    
    //funçao alterar agenda de pagamento
    public void AlterarAgendaPagamento(Empregados empregado)
    {
        Scanner scanner = new Scanner(System.in);
        int opcao;
        System.out.println("As opções são as seguintes: ");
        if(empregado.getFrequencia()==1)
        {
            System.out.println("1.para domingo.\n2.para segunda.\n3.para terça.\n4.para quarta.\n5.para quinta.\n6.para sexta.\n7.para sábado.");            
            opcao = scanner.nextInt();
            empregado.setDiadepagamento(opcao);  
        }
        if(empregado.getFrequencia()==2)
        {
            System.out.println("1.para domingo.\n2.para segunda.\n3.para terça.\n4.para quarta.\n5.para quinta.\n6.para sexta.\n7.para sábado.");            
            opcao = scanner.nextInt();
            empregado.setDiadepagamento(opcao); 
        }
        if(empregado.getFrequencia()==3)
        {
             System.out.println("Digite o dia do mês que o funcionário será pago");
             opcao = scanner.nextInt();
             empregado.setDiadepagamento(opcao); 
        }
    }
    //fim da função alterar agenda de pagamento
}
