package main;
import java.util.Scanner;
import java.util.Stack;
public class ListaEmpregados {
    
    java.util.ArrayList<Empregados> ListaEmpregados = new java.util.ArrayList<Empregados>();
    
    //método para adicionar empregado na lista
    public void Incluir(Empregados empregado)
    {
        ListaEmpregados.add(empregado);
        System.out.println("O número de identificação do funcionário "+empregado.getNome()+" é "+empregado.getId()+".");
    }
    //fim dométodo para adicionar empregado na lista
    
    //opção de lançar cartão de ponto
    public void MarcarPonto(int id)
    {
        int i;
        Scanner scanner = new Scanner(System.in);
        Empregados individuo = new Empregados();
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            if(individuo.getId()==id)
            {
                  System.out.println("o funcionário de id "+id+" tem "+individuo.getNome()+".");
                  System.out.println("por favor, digite sim ou nao para confirmar a ação.");
                  String opcao = scanner.nextLine();
                  if(opcao.equals("sim"))
                  {
                      if(individuo.getType().equals("horista"))
                    {
                        if(individuo.ponto.getHorachegada()==0)
                        {
                            
                            System.out.println("Insira a hora de chegada: ");
                            individuo.ponto.AdicionarChegada();
                        }
                        else
                        {
                            System.out.println("Insira a hora de saída: ");
                            individuo.ponto.AdicionarSaida();
                        }
                    }
                    else
                    {
                     System.out.println("O funcionário "+individuo.getNome()+ " não é horista");
                    }
                  }
                  else
                  {
                      return;
                  }
                    
            }
        }
}           
 //fim da opção de lançar cartão de ponto   
    
 //opção de lançar vendas
    public void LancarVendas(int id)
    {
        int i, s;
        Scanner scanner = new Scanner(System.in);
        Empregados individuo = new Empregados();
        //inicio do loop
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            //inicio da verificação de id
            if(individuo.getId()==id)
            {
                System.out.println("o funcionário de id "+id+" tem "+individuo.getNome()+".");
                System.out.println("por favor, digite sim ou nao para confirmar a ação.");
                String opcao = scanner.nextLine();
                if(opcao.equals("sim"))
                {
                    if(individuo.getType().equals("comissionado"))
                    {
                        System.out.println("Digite o dia(formato numérico) em que a venda foi realizada: ");
                        int dia = scanner.nextInt();
                        individuo.datasVendas.add(dia);
                        System.out.println("Digite o número de vendas realizada no dia "+dia +": ");
                        int vendas = scanner.nextInt();
                        individuo.vendas.add(vendas);
                        if(individuo.getPercentualvendas()==0)
                        {
                            System.out.println("Digite o percentual que será colocado sob as vendas.");
                            int percentual = scanner.nextInt();
                            individuo.setPercentualvendas(percentual);
                        }
                        
                    }
                    else
                    {
                        System.out.println("O funcionário "+individuo.getNome()+" não é comissionado");
                    }
                }
                else
                {
                    return;
                }
            }
        }
    }
    //fim da opção de lançar vendas
    
    //opção de lançar taxas de sindicatos e serviçõs adicionais
    public void LancarTaxas(int id)
    {
         int i, s;
        Scanner scanner = new Scanner(System.in);
        Empregados individuo = new Empregados();
        //inicio do loop
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            //inicio da verificação de id
            if(individuo.getId()==id)
            {
                System.out.println("o funcionário de id "+id+" tem "+individuo.getNome()+".");
                System.out.println("por favor, digite sim ou nao para confirmar a ação.");
                String opcao = scanner.nextLine();
                if(opcao.equals("sim"))
                {
                    if(individuo.getSindicato().equals("sim"))
                    {
                        individuo.AdicionarInfoSindicais(id);
                    }
                    else
                    {
                        System.out.println("O funcionário "+individuo.getNome()+" não faz parte de nenhum sindicato.");
                    }
                }
                else
                {
                    return;
                }
            }
        } 
    }
     //fim da opção de lançar taxas de sindicatos e serviços adicionar
    
    //funcionalidade alterar detalhes do funcionário
    public void AlterarDetalhes(int id)
    {
        int i;
        Empregados individuo = new Empregados();
        Scanner scanner = new Scanner(System.in);
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            if(individuo.getId()==id)
            {
                System.out.println("o funcionário de id "+id+" tem "+individuo.getNome()+".");
                System.out.println("por favor, digite sim ou nao para confirmar a ação.");
                String opcao = scanner.nextLine();
                if(opcao.equals("sim"))
                {
                    individuo.AlterarDetalhes(individuo);
                }
                else
                {
                    return;
                }
            }
        }
    }
    //fim funcionalidade alterar detalhes do funcionário
    
    //método para procurar empregado horista
    public void ProcurarEmpregadoHorista(int dia)
    {
        int i;
        Empregados individuo = new Empregados();
        FolhaDePagamento folha = new FolhaDePagamento();
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            if(individuo.getType().equals("horista") && individuo.getDiadepagamento()==dia)
            {
               if(individuo.ponto.getHorachegada()!=0 && individuo.ponto.getHorasaida()!=0)
               {
                   folha.GerarPagamentoHorista(individuo, dia);
               }
               else
               {
                   System.out.println("O funcionário não trabalhou nenhuma hora.");
               }
               
            }
        }
    }
     //fim do método para procurar empregado horista
    
     //método para procurar empregado comissionado
    public void ProcurarEmpregadoComissionado(int dia, int semana)
    {
        int i;
        Empregados individuo = new Empregados();
        FolhaDePagamento folha = new FolhaDePagamento();
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            if(individuo.getType().equals("comissionado") && individuo.getDiadepagamento()==dia && semana%2==0)
            {
               folha.GerarPagamentoComissionado(individuo, dia);
            }
        }  
    }
    //fim do método para procurar empregado comissionado
    
    //método para procurar empregado assalariado
    public void ProcurarEmpregadoAssalariado(int dia)
    {
       int i;
        Empregados individuo = new Empregados();
        FolhaDePagamento folha = new FolhaDePagamento();
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            if(individuo.getType().equals("assalariado") && individuo.getDiadepagamento()==dia)
            {
               folha.GerarPagamentoAssalariado(individuo, dia);
            }
        }   
        
    }
     //fim do método para procurar empregado assalariado
    
    //funcionalidade remover
    public void Remover(int id, Stack<Empregados> stack)
    {
        int i;
        Scanner scanner = new Scanner(System.in);
        Empregados individuo = new Empregados();
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            if(individuo.getId()==id)
            {
                System.out.println("o nome do funcionário associdado ao id "+id+" é "+individuo.getNome()+".");
                System.out.println("por favor, digite sim ou nao para confirmar a ação.");
                String opcao = scanner.nextLine();
                if(opcao.equals("sim"))
                {
                    individuo.setAcao("rem");
                    stack.push(individuo);
                    ListaEmpregados.remove(individuo);
                }
                else
                {
                    return;
                }
                
            }
        }
    }  
    //fim da funcionalidade remover
        
    
    //método para procurar um empregado na lista
    public void PercorrerLista(int id)
    {
        int i;
        Empregados individuo = new Empregados();
        FolhaDePagamento folha = new FolhaDePagamento();
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            if(individuo.getId()==id)
            {
                folha.AgendaPagamento(individuo);
            }
        }
    } 
    //fim  método para procurar um empregado na lista
    
    
    //método para zerar as horas de trabalho registradas por empregados horista quando
    //a folha de pagamento for rodada
    public void ZerarHoras()
    {
        Empregados individuo = new Empregados();
        int i;
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            individuo.ponto.setHorachegada(0);
            individuo.ponto.setHorasaida(0);
            individuo.ponto.setHoratotal(0);
        }
    } 
    //fim
    
    //funcionalidade UndoRedo
    public void UndoRedo(int id, Stack<Empregados> stack, Empregados empregado)
    {
        int i;
        Empregados individuo = new Empregados();
        for(i=0;i<ListaEmpregados.size();i++)
        {
            individuo = ListaEmpregados.get(i);
            if(individuo.getId()==id)
            {
              if(individuo.getAcao().equals("add"))
              {
                  individuo.setAcao("rem");
                  stack.push(individuo);
                  ListaEmpregados.remove(ListaEmpregados.get(i));
              }
              else if(individuo.getAcao().equals("rem"))
              {
                  empregado.setAcao("add");
                  stack.push(empregado);
                  ListaEmpregados.add(empregado);
              }
            }
        }
    }
    //fim da funcionalidade UndoRedo
 }