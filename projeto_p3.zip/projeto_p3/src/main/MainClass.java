package main;
import java.util.Scanner;
import java.util.Calendar;
import java.util.Stack;


public class MainClass {
    
    public static void main(String[] args)
    {
      ListaEmpregados lista = new ListaEmpregados();
      Calendar current = Calendar.getInstance();
      CartaoPonto Ponto = new CartaoPonto();
      FolhaDePagamento folha = new FolhaDePagamento();
      Scanner scanner = new Scanner(System.in); 
      Stack<Empregados> undo = new Stack<Empregados>(); 
      Stack<Empregados> redo = new Stack<Empregados>(); 
      //UndoRedo acao = new UndoRedo();
      int dia_semana = folha.VerificarDiaSemana();
      int dia_mes = folha.VerificarDiaMes();
      int mes = current.get(Calendar.MONTH);
      int ano = current.get(Calendar.YEAR);
      int option, i=1, id, semana=1;
      System.out.println("dia da semana= "+dia_semana+"\ndia do mes= "+dia_mes);
      System.out.println("Digite 1 para adicionar empregado.");
      System.out.println("Digite 2 para remover empregado.");
      System.out.println("Digite 3 para lançar um cartão de Ponto.");
      System.out.println("Digite 4 para lançar um resultado de Venda.");
      System.out.println("Digite 5 para lançar taxa sindical ou de serviços adicionais.");
      System.out.println("Digite 6 para alterar detalhes de um empregado.");
      System.out.println("Digite 7 para gerar folha de pagamento do dia.");
      System.out.println("Digite 8 para dar undo/redo.");
      System.out.println("Digite 9 para ver as agendas de pagamento.");
      System.out.println("Digite 10 para criar novas agendas de pagamento.");
      System.out.println("Digite 11 para sair do sistema.");
      option = scanner.nextInt();
      mes++;
      semana=2;
      dia_semana=6;
      while(option!=11)
      {
          if(option==1)
          {
            System.out.println("Você entrou na opção adicionar empregado.");
            Empregados empregado = new Empregados();
            empregado.AdicionarEmpregado(i);
            lista.Incluir(empregado);
            empregado.setAcao("add");
            i++;
            undo.push(empregado);
          }
          if(option==2)
          {
             System.out.println("Você entrou na opção remover empregado.");
             System.out.println("Digite o número de identificação(ID) do funcionário que será removido:");
             id = scanner.nextInt();
             lista.Remover(id, undo); 
          }
          if(option==3)
          {
              System.out.println("Você entrou na opção lançar cartão de ponto.");
              System.out.println("Digite o número de identificação(ID) do funcionário:");
              id = scanner.nextInt();
              lista.MarcarPonto(id);
          }
          if(option==4)
          {
              System.out.println("Você entrou na opção lançar resultado de vendas");
              System.out.println("Digite o número de identificação(ID) do funcionário: ");
              id = scanner.nextInt();
              lista.LancarVendas(id);
          }
          if(option==5)
          {
              System.out.println("Você entrou na opção lançar taxas de sindicato e adicionais.");
              System.out.println("Digite o número de identificação(ID) do funcionário: ");
              id = scanner.nextInt();
              lista.LancarTaxas(id);
          }
          if(option==6)
          {
             System.out.println("Você entrou na opção alterar detalhes de um funcionário.");
             System.out.println("Digite o número de identificação(ID) do funcionário: ");
             id = scanner.nextInt();
             lista.AlterarDetalhes(id);
             
          }
          if(option==7)
          {
            
              System.out.println("Você entrou na opção de gerar a folha de pagamento do dia.");
              System.out.println("A cada dia que se passa, todo funcionário horista tem suas horas de trabalho zerada.");
              System.out.println("Folha de pagamento gerada em "+dia_mes+"/"+mes+"/"+ano+".");
              lista.ProcurarEmpregadoAssalariado(dia_mes);
              lista.ProcurarEmpregadoHorista(dia_semana);   
              lista.ProcurarEmpregadoComissionado(dia_semana, semana);
              dia_semana++;
              dia_mes++;
              lista.ZerarHoras();
              if(dia_mes>Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH))
              {
                  dia_mes=1;
                  mes++;
              }
              if(dia_semana>7)
              {
                  semana++;
                  dia_semana=1;
              }
              
          }
          if(option==8)
          {
              Empregados empregado = new Empregados();
              System.out.println("Para desfazer uma ação digite undo ou para refazer uma ação digite redo ou sair para voltar ao menu principal.");
              scanner.nextLine();
              String acao_s = scanner.nextLine();
              if(acao_s.equals("undo"))
              {
                  empregado = undo.pop();
                  lista.UndoRedo(empregado.getId(), redo, empregado);
              }
              if(acao_s.equals("redo"))
              {
                  empregado = redo.pop();
                  if(empregado.getAcao().equals("rem"))
                  {
                      empregado.setAcao("add");
                      lista.Incluir(empregado);
                  }
                  else if(empregado.getAcao().equals("add"))
                  {
                      lista.UndoRedo(empregado.getId(), undo, empregado);
                  }
                  else
                  {
                      lista.UndoRedo(empregado.getId(), undo, empregado);
                  }
              }
              if(acao_s.equals("sair"))
              {
                  return;
              }
          }
          if(option==9)
          {
              System.out.println("Você entrou na opção agenda de pagamento.");
              System.out.println("Digite o número de identificação do funcionário: ");
              id = scanner.nextInt();
              lista.PercorrerLista(id);   
          }
          if(option==10)
          {
              System.out.println("Você entrou na opção criar nova agenda de pagamento.");
              System.out.println("Digite o número de identificação do funcionário: ");
              id = scanner.nextInt();
              lista.PercorrerLista(id);       
          }
         
          System.out.println("Escolha outra opção: ");
          option = scanner.nextInt();
      }
    }  
    
}
