package main;

import java.util.Scanner;

public class CartaoPonto {
   
    private int horachegada = 0;
    private int horasaida = 0;
    private int horatotal =0;
    Scanner scanner = new Scanner(System.in);
    
    public int getHorachegada() {
        return horachegada;
    }

    public void setHorachegada(int horachegada) {
        this.horachegada = horachegada;
    }

    public int getHorasaida() {
        return horasaida;
    }

    public void setHorasaida(int horasaida) {
        this.horasaida = horasaida;
    }

    public int getHoratotal() {
        return horatotal;
    }

    public void setHoratotal(int horatotal) {
        this.horatotal = horatotal;
    }
    
    //método para adicionar a hora inicial que o funcionário bateu ponto
    public void AdicionarChegada()
    {
       horachegada = scanner.nextInt();
       setHorachegada(horachegada);        
    }
    //fim
    
    //método para adicionar a hora final que o funcionário bateu ponto
    public void AdicionarSaida()
    {
        horasaida = scanner.nextInt();
        setHorasaida(horasaida);
        setHoratotal(getHorasaida() -  getHorachegada());
    }
    //fim
    
}
