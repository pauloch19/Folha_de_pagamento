package main;

import java.util.Scanner;
import java.util.Calendar;
public class Empregados {
    
	private String name = new String();
        private String adress = new String();
        private String type = new  String();
        private String sindicato = new String();
        private String formadepagamento = new String();
        private String acao = new String ();
        private int diadepagamento = 0;
        java.util.ArrayList<Integer> vendas = new java.util.ArrayList<Integer>();
        java.util.ArrayList<Integer> datasVendas = new java.util.ArrayList<Integer>();
        private int salary = 0; //salário dado pelo usuário
        private int salary_final =0; //salário calculado com taxa
        private int id = 0;
        private int taxasindical =0;
        private int taxasadicionais =0;
        private int idsindicato =0;
        private int percentualvendas=0;
        private int frequencia=0;
        CartaoPonto ponto = new CartaoPonto();
        Scanner scanner = new Scanner(System.in);

    public int getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(int frequencia) {
        this.frequencia = frequencia;
    }

    public String getFormadepagamento() {
        return formadepagamento;
    }

    public void setFormadepagamento(String formadepagamento) {
        this.formadepagamento = formadepagamento;
    }
        

    public int getIdsindicato() {
        return idsindicato;
    }

    public void setIdsindicato(int idsindicato) {
        this.idsindicato = idsindicato;
    }

    public int getTaxasindical() {
        return taxasindical;
    }

    public void setTaxasindical(int taxasindical) {
        this.taxasindical = taxasindical;
    }

    public int getTaxasadicionais() {
        return taxasadicionais;
    }

    public void setTaxasadicionais(int taxasadicionais) {
        this.taxasadicionais = taxasadicionais;
    }
    
    public int getDiadepagamento() {
        return diadepagamento;
    }

    public void setDiadepagamento(int diadepagamento) {
        this.diadepagamento = diadepagamento;
    }
        
        public void setSindicato(String sindicato)
        {
            this.sindicato = sindicato;
        }
       
        public void setSalaryfinal(int salary)
        {
            this.salary_final = salary;
        }
        
        public void setId(int id)
        {
            this.id = id;
        }
        
        public void setNome(String name){
            this.name = name;
        }
        
        public void setAdress(String adress)
        {
            this.adress = adress;
        }
        
        public void setType(String type)
        {
            this.type = type;
        }
        
        public void setSalary(int salary)
        {
            this.salary = salary;
        }
        
        public String getNome()
        {
            return this.name;
        }
        
        public String getAdress()
        {
           return this.adress;
        }

        public int getPercentualvendas() {
            return percentualvendas;
        }

        public void setPercentualvendas(int percentualvendas) {
            this.percentualvendas = percentualvendas;
        }
        
        public String getType()
        {
           return this.type;
        }
        
        public int getSalary()
        {
            return this.salary;
        }
        
        public int getId()
        {
            return this.id;
        }
        
        public int getSalaryfinal()
        {
            return this.salary_final;
        }
        
        public String getSindicato()
        {
            return this.sindicato;
        }
        
         public String getAcao() {
        return acao;
        }

        public void setAcao(String acao) {
            this.acao = acao;
        }
        
        //Opção Adicionar Empregado
        public void AdicionarEmpregado(int id) {
            System.out.println("Informe o nome do funcionário: ");
            name = scanner.nextLine();
            setNome(name);
            System.out.println("Informe o endereço do funcionário: ");
            adress = scanner.nextLine();
            setAdress(adress);
            System.out.println("Informe o tipo do funcionário: ");
            System.out.println("Para o funcionamento do sistema, digite:\nhorista\ncomissionado\nassalariado.");
            type = scanner.nextLine();
            setType(type);
            if(type.equals("horista") || type.equals("Horista"))
            {
                setDiadepagamento(6);
                setFrequencia(1);
            }
            if(type.equals("comissionado") || type.equals("Comissionado"))
            {
                 setDiadepagamento(6);
                 setFrequencia(2);
            }
            if(type.equals("assalariado") || type.equals("Assalariado"))
            {
                setDiadepagamento(Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH));
                setFrequencia(3);
            }
            System.out.println("Informe o salário do funcionário: ");
            salary =  scanner.nextInt();
            setSalary(salary);
            System.out.println("Informe a forma de pagamento: ");
            scanner.nextLine();
            formadepagamento = scanner.nextLine();
            setFormadepagamento(formadepagamento);
            System.out.println("o funcionário participa de sindicato: ");
            sindicato = scanner.nextLine();
            setSindicato(sindicato);
            setId(id);
	}
        //Fim da opção Adicionar Empregado
        
        //método para adicionar informações sindicais
        public void AdicionarInfoSindicais(int id)
        {
                    System.out.println("Qual taxa sindical será cobrada ao funcionário "+getNome()+"?");
                    int taxa = scanner.nextInt();
                    setTaxasindical(taxa);
                    System.out.println("Qual taxa de serviços adicionais será cobrada ao funcionário "+getNome()+"?");
                    taxa = scanner.nextInt();
                    setTaxasadicionais(taxa);
                    System.out.println("O número de identificação do funcionário para o sindicato será gerado automaticamente.");
                    System.out.println("O número de identificação será: "+id*5+".");
                    setIdsindicato(id*5);
        }
        //fim do método para adicionar informações sindicais
        
        //Opção alterar detalhes do funcionário
        public void AlterarDetalhes(Empregados individuo)
        {
           
           System.out.println("Deseja alterar o nome do funcionário "+individuo.getNome()+"?");
           System.out.println("Digite a palavra sair para voltar ao menu principal ou digite sim para prosseguir");
           String opcao = scanner.nextLine();
           if(opcao.equals("sim"))
           {
               System.out.println("Digite o novo nome do funcionário: ");
               name = scanner.nextLine();
               individuo.setNome(name);
           }
           if(opcao.equals("sair"))
           {
               return;
           }
           System.out.println("Deseja alterar o endereço do funcionário "+individuo.getNome()+"?");
           System.out.println("Digite a palavra sair para voltar ao menu principal ou digite sim para prosseguir");
           opcao = scanner.nextLine();
           if(opcao.equals("sim"))
           {
               System.out.println("Digite o novo endereço do funcionário: ");
               adress = scanner.nextLine();
               individuo.setAdress(adress);
           }
            if(opcao.equals("sair"))
           {
               return;
           }
           System.out.println("Deseja alterar o tipo do funcionário "+individuo.getNome()+"?");
           System.out.println("Digite a palavra sair para voltar ao menu principal ou digite sim para prosseguir");
           opcao = scanner.nextLine();
           if(opcao.equals("sim"))
           {
               System.out.println("Digite o novo tipo do funcionário: ");
               type = scanner.nextLine();
               individuo.setType(type);
               //o salário final terá que ser recalculado
           }
            if(opcao.equals("sair"))
           {
               return;
           }
           System.out.println("Deseja alterar o salário do funcionário "+individuo.getNome()+"?");
           System.out.println("Digite a palavra sair para voltar ao menu principal ou digite sim para prosseguir");
           opcao = scanner.nextLine();
           if(opcao.equals("sim"))
           {
               System.out.println("Digite o novo endereço do funcionário: ");
               salary = scanner.nextInt();
               individuo.setSalary(salary);
           }
            if(opcao.equals("sair"))
           {
               return;
           }
           System.out.println("Deseja alterar a participação sindical do funcionário "+individuo.getNome()+"?");
           System.out.println("Digite a palavra sair para voltar ao menu principal ou digite sim para prosseguir");
           opcao = scanner.nextLine();
           if(opcao.equals("sim"))
           {
               System.out.println("Informe se ele participa do sindicato:(digite sim ou nao)");
               sindicato = scanner.nextLine();
               individuo.setSindicato(sindicato);
           }
            if(opcao.equals("sair"))
           {
               return;
           }
           System.out.println("Atualmente o número de identificação do funcionário é: "+individuo.getIdsindicato()+".");
           System.out.println("Digite a palavra sair para voltar ao menu principal ou digite sim para prosseguir");
           opcao = scanner.nextLine();
           if(opcao.equals("sim"))
           {
               System.out.println("Será gerado outro número de identificação automaticamente.");
               System.out.println("o novo número de identificação séra "+individuo.getIdsindicato()*7+".");
               individuo.setIdsindicato(individuo.getIdsindicato()*7);
           }
           else
           {
               return;
           }
        }
        //Fim da opção alterar detalhes do funcionário
}
